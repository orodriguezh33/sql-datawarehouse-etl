# SQL Data Warehouse ETL Pipeline

[![SQL Server](https://img.shields.io/badge/SQL%20Server-2022-CC2927?logo=microsoftsqlserver)](https://www.microsoft.com/sql-server)
[![Python](https://img.shields.io/badge/Python-3.12-3776AB?logo=python&logoColor=white)](https://www.python.org/)
[![Docker](https://img.shields.io/badge/Docker-Compose-2496ED?logo=docker&logoColor=white)](https://www.docker.com/)

My first data engineering project. Took a SQL tutorial and added Python automation + Docker to make it production-ready.

---

## What This Is

Built from [Data Baraa's SQL Data Warehouse tutorial](https://www.youtube.com/watch?v=9GVqKuTVANE). The tutorial teaches SQL and data warehousing in pure SQL - I extended it with:

- **Python orchestration** to run everything automatically
- **Docker containers** so it works on any machine  
- **Data validation** at each transformation layer
- **Error handling** that stops if something breaks

Transforms CSV data (CRM + ERP sources) through Bronze → Silver → Gold layers into a star schema ready for BI tools.

**Time spent:** ~3 weeks (nights and weekends)

---

## Quick Start

```bash
git clone [your-repo-url]
cd sql-datawarehouse-etl
docker compose up --build
```

First run takes ~5 min (downloads SQL Server image). After that ~45 seconds.

**Output:**
```
▶ Create Schemas
▶ Create Bronze Tables
▶ Load Bronze (SQL script)
▶ Bronze row counts
▶ Create Silver Tables
▶ Execute silver.load_silver
▶ Silver row counts
▶ Create Gold Views
▶ Gold view row counts
✅ ETL end-to-end executed successfully
```

Connect to database:
- Host: `localhost:1433`
- User: `sa`
- Password: (see `.env` file)
- Database: `DataWarehouse`

---

## Architecture

```
CSV Files → BRONZE (raw) → SILVER (cleaned) → GOLD (analytics)
```

**Bronze:** 6 tables with raw data from CSVs  
**Silver:** Same tables but cleaned (dates fixed, nulls handled)  
**Gold:** 3 views in star schema (1 fact + 2 dimensions)

![Data Flow](./docs/diagrams/data_flow.png)

---

## Project Structure

```
sql-datawarehouse-etl/
├── datasets/
│   ├── source_crm/          # 3 CSV files
│   └── source_erp/          # 3 CSV files
├── sql/
│   ├── 00_setup/           # Database creation
│   ├── 10_bronze/          # Raw data load
│   ├── 20_silver/          # Transformations
│   ├── 30_gold/            # Star schema views
│   └── test/               # Quality checks
├── etl/
│   ├── pipeline.py         # Main orchestration
│   ├── runners.py          # SQL execution
│   └── stages/             # Bronze/Silver/Gold logic
├── docker-compose.yml
├── Dockerfile
└── main.py
```

---

## What I Learned

**Docker networking was tough**  
Spent a whole day figuring out why `localhost` didn't work inside containers. Had to use the service name `sqlserver` instead. Also learned that health checks are essential - container "started" ≠ "ready to accept connections".

**Data validation matters**  
Added checks after each layer. If Bronze load fails, no point running Silver. Catches problems early instead of debugging broken Gold views.

**Automation is harder than it looks**  
First version used `os.system()` - couldn't catch errors properly. Switched to `subprocess`. Also tried `pyodbc` but had encoding issues, ended up using `sqlcmd`.

**Bronze/Silver/Gold makes sense**  
At first seemed like extra work, but when I found bad data I could reprocess Silver without reloading CSVs. Bronze = audit trail.

---

## Tech Stack

- **SQL Server 2022** - the database
- **Python 3.12** - orchestration and automation  
- **Docker Compose** - runs both SQL Server and ETL containers
- **sqlcmd** - executes SQL scripts

---

## Known Issues

- CSV parsing breaks if there are commas inside text fields
- Error messages just show SQL Server errors (not very helpful)
- No retry logic for connection failures
- Would be better to use `pyodbc` instead of `sqlcmd` for better error handling

---

## What's Mine vs Tutorial

**From the tutorial (Data Baraa):**
- SQL scripts for Bronze/Silver/Gold transformations
- Star schema design
- BULK INSERT patterns
- Table structures and relationships

**What I built:**
- All Python code (`etl/` directory)
- Docker setup (`Dockerfile`, `docker-compose.yml`)
- Automated execution and ordering of SQL scripts
- Validation framework (`test/` SQL scripts + Python checks)
- Error handling and logging
- Project organization and structure

---

## Screenshots

### Pipeline Running
![Pipeline Output](./imgs/etl_runner.png)

### Data Integration
![Tables in SSMS](./imgs/Data%20Integration.png)
### Data Flow
![Tables in SSMS](./imgs/DataFLow.png)
### Data Mart
![Tables in SSMS](./imgs/DataMart.png)

---

## Credits

Based on [Data Baraa's SQL Data Warehouse tutorial series](https://www.youtube.com/@DataWithBaraa). Great resource for learning SQL and dimensional modeling.

---

## License

MIT License

---

**⭐ Star if you found this useful!**

*First data engineering project - feedback welcome*